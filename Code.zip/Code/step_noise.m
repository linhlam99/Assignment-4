set(0,'DefaultFigureWindowStyle','docked')
clc 
clear
close all
R1=1;
C=0.25;
R2=2;
L=0.2;
R3=15;
a=100;
R4=0.1;
R0=1000;
G1=1/R1;
G2=1/R2;
G3=1/R3;
G4=1/R4;
G0=1/R0;
Cn=0.00001;
G= [ G1 -G1 0 0 0 1 0;
    1 0 0 0 0 0 0; 
    -G1 G1+G2 0 0 0 0 1;
    0 0 -G3 0 0 0 1;
    0 0 0 -G4 G4+G0 0 0;
    0 0 a*G3 -1 0 0 0;
    0 1 -1 0 0 0 0];
C= [ C -C 0 0 0 0 0;
    0 0 0 0 0 0 0;
    -C C 0 0 0 0 0;
    0 0 Cn 0 0 0 0;
    0 0 0 0 0 0 0;
    0 0 0 0 0 0 0;
    0 0 0 0 0 0 -L];
iter=1000;
V=zeros(iter,7);
Vin=zeros(iter,1);
dt=1/iter;
Vin(1:30) = 0;
Vin(30:iter) = 1;
t=zeros(iter,1);
t(1) = dt;
% In=rand(iter); %random noise 
In=0.001*randn(iter); %gaussian distribution 
for i=2:iter
    t(i,:)=i*dt;
    F= [0; Vin(i); 0; In(i);0;0;0];
    H=C./dt + G;
    V(i,:)=(H\(F+(C*V(i-1,:).'/dt))).';
end
plot(t,Vin)
hold on
plot(t,V(:,5))
legend('Vin','V0');
xlabel('time second')
ylabel('voltage V')
