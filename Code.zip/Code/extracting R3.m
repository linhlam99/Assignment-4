clear, clc,close all
set(0,'DefaultFigureWindowStyle','docked')
set(0,'defaultaxesfontsize',20)
set(0,'defaultaxesfontname','Times New Roman')
set(0,'DefaultLineLineWidth', 2);
W=200e-9;
L=300e-9;
pin=1e-2; % conductivity inside the box
pout=1; %conductivity outside the box
nx=120;
ny=80;
N=4000; %number of particles
x=linspace(0,L,nx);
y=linspace(0,W,ny);
V=zeros(nx,ny);
G=sparse(nx*ny,nx*ny);
% V0=linspace(0,1.10,100);           % applied voltage
F=zeros(nx*ny,1);
a=1e-07;
b=1e-7;
d=1.5e-7; %bottle neck width
c=W/2-d/2;
timesteps=1000;
T=300;
kb=1.38064852e-23;
m0=9.1e-31;
mn=0.26*m0;
vth =sqrt((2*kb*T)/mn);
vx=vth*rand(N,1).*(round(rand(N,1)).*2-1);
vy=sqrt(vth.^2-vx.^2).*(round(rand(N,1)).*2-1);
Nplot=randi(N,10,1);
dt = W/vth/100 -0.3e-15;
tmn=0.2e-12;
box_on=1; %turn on box
C=pout*ones(nx,ny);% define conductivity
concentration=1e15; %cm^-2
V0array=linspace(0.1,10,30);
I0array=zeros(30,1);
[Gx,Gy]=meshgrid(x,y);
for nV=1:30
    V0=V0array(nV);
    for i=1:nx
        for j=1:ny
            if x(i)>a && x(i)<a+b && (y(j)<c || y(j)>c+d)
                C(i,j) = pin;
            end
        end
    end
    for i =1:nx
        for j=1:ny
            n = j+(i-1)*ny;
            if i ==1
                F(n)=V0;
            elseif i ==nx
                F(n)=0;
            end
            if i==1 || i==nx
                G(n,n) = 1;
            elseif j==1
                nxm= j+(i-2)*ny;
                nxp=j+(i)*ny;
                nyp=j+1+(i-1)*ny;
                cxm = (C(i-1,j)+C(i,j))/2;
                cxp = (C(i+1,j)+C(i,j))/2;
                cyp = (C(i,j+1)+C(i,j))/2;
                G(n,nxm)=cxm;
                G(n,nxp)=cxp;
                G(n,nyp)=cyp;
                G(n,n)=-(cxm+cxp+cyp);
            elseif j ==ny
                nxm= j+(i-2)*ny;
                nxp=j+(i)*ny;
                nym=j-1+(i-1)*ny;
                cxm = (C(i-1,j)+C(i,j))/2;
                cxp = (C(i+1,j)+C(i,j))/2;
                cym = (C(i,j-1)+C(i,j))/2;
                G(n,nxm)=cxm;
                G(n,nxp)=cxp;
                G(n,nym)=cym;
                G(n,n)=-(cxm+cxp+cym);
            else
                nxm= j+(i-2)*ny;
                nxp=j+(i)*ny;
                nym=j-1+(i-1)*ny;
                nyp=j+1+(i-1)*ny;
                cxm = (C(i-1,j)+C(i,j))/2;
                cxp = (C(i+1,j)+C(i,j))/2;
                cym = (C(i,j-1)+C(i,j))/2;
                cyp = (C(i,j+1)+C(i,j))/2;
                G(n,nxm)=cxm;
                G(n,nxp)=cxp;
                G(n,nyp)=cyp;
                G(n,nym)=cym;
                G(n,n)=-(cxm+cxp+cyp+cym);
            end
        end
    end
    P=G\F;
    for i=1:nx
        for j=1:ny
            n=j+(i-1)*ny;
            V(i,j)=P(n);
        end
    end
    [Ey, Ex] = gradient(V);
    q=1.6e-19;
    scatter=1-exp(-dt/tmn);
    none_in_box = 0;
    dx= discretize(x, nx);
    dy= discretize(y, ny);
    xd = rand(N,1)*L;
    yd = rand(N,1)*W;
    for k = 1:timesteps
        InsideBoxes = xd>a & xd<(a+b) & (yd<c | yd>c+d);
        if sum(InsideBoxes) == 0
            none_in_box = 1;
            break;
        end
        xd(InsideBoxes) = rand(sum(InsideBoxes),1)*L;
    end
    if none_in_box==0
        brkpt = 1;
    end
   
    for iter = 1:timesteps
        xp=xd;
        yp=yd;
        xd=xp+vx*dt;
        yd=yp+vy*dt;
        xp(xd>=L)=xp(xd>=L)-L;
        xp(xd<=0)=xp(xd<=0)+L;
        xd(xd>=L)=xd(xd>=L)-L;
        xd(xd<=0)=xd(xd<=0)+L;
        vy(yd>=W)=vy(yd>=W)*(-1);
        vy(yd<=0)=(-1)*vy(yd<=0);
        V2 = sqrt(mean(vx.^2 + vy.^2));
        Temp = (V2).^2*mn/(2*kb);
        ip = scatter > rand(N,1);
        Ex_new=interp2(Gx,Gy,Ex.',xp,yp);
        Ey_new=interp2(Gx,Gy,Ey.',xp,yp);
        Ex_new(isnan(Ex_new))=0;
        Ey_new(isnan(Ey_new))=0;
        Fx=-Ex_new.*q.*nx/L;
        ax_new=Fx./mn;
        Fy=-Ey_new.*q.*ny/W;
        ay_new=Fy./mn;
        vx=vx+ax_new.*dt;
        vy=vy+ay_new.*dt;
        xd=xd+vx*dt+0.5*ax_new*(dt)^2;
        yd=yd+vy*dt+0.5*ay_new*(dt)^2;
        vx(ip)=vth.*randn(sum(ip),1);
        vy(ip)=vth.*randn(sum(ip),1);
        InBox = xd > a & xd < a+b & (yd> d+c| yd<c);
        outsidebox = xp < a | xp > a+b;
        xd(InBox & outsidebox) = xp(InBox & outsidebox);
        vx(InBox & outsidebox) = -vx(InBox & outsidebox);
        vy(InBox & ~outsidebox) = -vy(InBox & ~outsidebox);
        yd(InBox & ~outsidebox) = yp(InBox & ~outsidebox);
    end
    vx_ave=mean(vx);
    Jx=q*concentration*vx_ave*1e4;
    I0array(nV)=Jx.*W;
end
% ft1=fitlm(I0array,V0array, 1);
% txt=sprintf('V = %.4f*I %+.4f',Poly(1), Poly(2));
ft1=fittype({'x'})
plot(V0array,I0array)
xlabel('V'), ylabel('I')
R3=fit(I0array,V0array',ft1)
