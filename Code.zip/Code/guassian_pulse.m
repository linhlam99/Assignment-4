set(0,'DefaultFigureWindowStyle','docked')
clc 
clear
close all
R1=1;
C=0.25;
R2=2;
L=0.2;
R3=15;
a=100;
R4=0.1;
R0=1000;
G1=1/R1;
G2=1/R2;
G3=1/R3;
G4=1/R4;
G0=1/R0;
G= [ G1 -G1 0 0 0 1 0;
    1 0 0 0 0 0 0; 
    -G1 G1+G2 0 0 0 0 1;
    0 0 G3 0 0 0 -1;
    0 0 0 -G4 G4+G0 0 0;
    0 0 a*G3 -1 0 0 0;
    0 1 -1 0 0 0 0];
C= [ C -C 0 0 0 0 0;
    0 0 0 0 0 0 0;
    -C C 0 0 0 0 0;
    0 0 0 0 0 0 0;
    0 0 0 0 0 0 0;
    0 0 0 0 0 0 0;
    0 0 0 0 0 0 -L];
iter=1000;
V=zeros(iter,7);
dt=1/iter;
% % part ii C gaussian pulse 
mag=1; % magnitude 
std=0.03; %std deviation
delay=0.06;
variance=std^2;
t=linspace(0,1,1000);
Vin=mag.*(exp(-(t-delay).^2/(2*variance)));
plot(t,Vin)
for i=2:iter 
    t(i)=dt*i;
    F= [0; Vin(i); 0; 0;0;0;0];
    H=C./dt + G;
    V(i,:)=(H\(F+(C*V(i-1,:).'/dt))).';
end
figure (4)
plot(t,Vin)
hold on
plot(t,V(:,5))
legend('Vin','V0');
xlabel('time second')
ylabel('voltage V')